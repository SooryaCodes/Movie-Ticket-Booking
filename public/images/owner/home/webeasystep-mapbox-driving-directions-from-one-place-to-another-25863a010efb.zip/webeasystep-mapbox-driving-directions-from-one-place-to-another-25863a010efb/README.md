in part two of google maps alternatives series ,and in this  tutorial you will learn :
1- search for place using geocode 
2- how to draw directions on a map 
3 - get driving directions from one location to another
4- get the distance and duration for this travel
5- how to get step by step directions on maps
6-how can we find directions on a map 

DEMO LINK
=========
http://webeasystep.com/demo/delivery-directions.html

Tutorial LINK
=========
https://www.youtube.com/watch?v=7vnVpw1o0zY